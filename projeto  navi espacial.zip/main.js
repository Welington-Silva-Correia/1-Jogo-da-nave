  let fim=document.querySelector('.fim')
  

    let ploasao = document.querySelector('.audio')
let vitoria=false
let inter,inter2
let sim=true
let sim2=true
let vidaplaneta=100
let telah=window.innerHeight
let telaw=window.innerWidth
let jogo
let frame
let dixjo,diyjo
let contbomba,painelcontbomba
let navi=document.querySelector('.navjog')
let can
let totalbomba=0


function reset(){
  dixjo=150
  diyjo=400
   navi.style.top = diyjo + "px"
   navi.style.left = dixjo + "px"
   
   
  jogo=true
  vitoria=false
   telah = window.innerHeight
   telaw = window.innerWidth
   contbomba=25
   vidaplaneta=100
   totalbomba=0
    document.querySelector('.barraplaneta').style.width=vidaplaneta*2+'px'
    


 //sim=true
 //sim2=true
//vidaplaneta=100
//telah=window.innerHeight
//telaw=window.innerWidth
   fim.style.display='none'
document.querySelector('.painel').
style.display = 'block'

document.querySelector('.telagmsg').style.display = 'none'



   
   cancelAnimationFrame(frame)
   clearInterval(inter)
   clearInterval(inter2)
   criar()
   inter= setInterval(criar,1000*4)
   gamelop()

 // bomba()
   
}
  //reset()



function direita(num){
  console.log(diyjo)
if(num==1){
  //direita
  dixjo+=20
} else if (num==2){
  //esquerda
  dixjo-=20

}else if(num==3){
  //pra cima
  diyjo-=20
  
} else{
  //pra baixo

  diyjo+=20
  
  
}

}

function controlajogador(){
  navi.style.top = diyjo + "px"
  navi.style.left = dixjo + "px"
}


function gamelop(){
  controlabomba()
  if (jogo){
    controletiro()
    controlajogador()
    
    
    colisão_tb()
    
    
  }
   else if(sim2){
     
//alert('ainda to rodando')
    fimdojogo()
    
    sim2=false 
  
  
    clearInterval(inter)
    clearInterval(inter2)
    //document.querySelectorAll('.bomba').forEach((bombas, index) => {
     // bombas.remove()
   // })
    //document.querySelectorAll('.atirajog').forEach((tiros, index) => {
     // tiros.remove()
   //controla })
  }
 frame=requestAnimationFrame(gamelop) 
}


let cont=400
function  controletiro(){
 if(jogo){
}else{
  fimdojogo()
}
  
  
  document.querySelectorAll('.atirajog').forEach((tiro)=>{
    let loc=0
    if(tiro){
      
      if(tiro.offsetTop<0){
        document.body.removeChild(tiro)
       // console.log(tiro)
      }
    //  console.log(tiro)
      
      
    let tiros=tiro.offsetTop
     loc=tiros-2
    tiro.style.top=loc+'px'
    }
  // console.log(tiros)
    //tiro.style.top=cont+'px';
    
  })
 // console.log('jsisd')
}



function atira(x,y){
  let t=document.createElement('div')
  
  
  t.setAttribute('class','atirajog')
 
  t.setAttribute('style','top:'+y+'px; left:'+ x+'px;')
  //console.log(t)
     
  document.body.appendChild(t)
  
 // alert('atirou')
  
}
document.addEventListener('click',function(event){
let n=document.activeElement.tagName

let name=event.target.nodeName
 //alert(event.target.id)
 
 if(jogo){
  if(name=='HTML'||name=='IMG'||event.target.id==='navjog'){
    let ploasao = document.querySelector('.audio1')
    ploasao.currentTime =0
    ploasao.play()
   atira(dixjo+28,diyjo-4)
 }
}
}
 )
  
function  bomba(){
  let aindatem=document.querySelectorAll('.bomba')
  if(jogo){
    let y=0
    let x=Math.ceil(Math.random()*351-1)
   
    let bomba=document.createElement('img')
    bomba.setAttribute('class','bomba')
    bomba.setAttribute('style','top:'+y+'px;left:'+x+'px;')
    bomba.setAttribute('src','missil22.gif')
  
    console.log(bomba)
    
    if(totalbomba<=contbomba){
    document.body.appendChild(bomba)
    
     contbomba--
   let bombas=(contbomba+1)*96/12
    document.querySelector('.barrabomba').style.width=bombas+'px'
    }else if(aindatem.length<1) {
   vitoria=true
    jogo=false
    
    //alert(vitoria)
    fimdojogo()
    }
    //alert(aindatem.length)
  }
 // requestAnimationFrame(bomba)
// cancelAnimationFrame(can)
 controlabomba()
}
//bomba()
/*bomba()
bomba()
bomba()*/
 function controlabomba(){
  if (jogo){
    
  }else{
    fimdojogo()
  }
  
   document.querySelectorAll('.bomba').forEach((bombas,index)=>{
     totalbomba++
     if(bombas){
     let conttop=bombas.offsetTop
     conttop+=1
     bombas.style.top=conttop+'px'
     
     }
   if(bombas.offsetTop>telah-250&&bombas.offsetTop<telah-248){
    vidaplaneta-=10
    document.querySelector('.barraplaneta').style.width=vidaplaneta*2+'px'
     ver('','',bombas,1)
    // bombas.remove()
     if(vidaplaneta<1){
       clearInterval(inter)
       jogo=false
       clearInterval(inter)
       clearInterval(inter2)
       document.querySelectorAll('.bomba').forEach((bombas, index) => {
         bombas.remove()
       })
       
     }
   }
     //requestAnimationFrame(controlabomba )
   })
// can=requestAnimationFrame(controlabomba)
// alert(totalbomba)
 
}
function criar(){
 bomba() 
inter2=setTimeout(
 bomba,1000)
 //alert('entrou')
}
//criar()

//criar()




function colisão_tb(){
  
  document.querySelectorAll('.bomba').forEach((bombas, index) => {
        totalbomba = index
        ver(bombas.offsetTop,bombas.offsetLeft,bombas)
        
  
  
  
})
}

function ver(topbomba,leftbomba,bombas,caio){
  if(caio==1){

    ploasao.currentTime = 0
     ploasao.play()
     bombas.src='explosão2.gif'
     setTimeout(()=>{
       bombas.remove()
     },900)
    // alert('caio'+caio)
  }
 
  else{
   // alert('nao caio'+caio)
  document.querySelectorAll('.atirajog').forEach((tiro) => {

  
   
        if(topbomba+40>tiro.offsetTop&&topbomba-5<tiro.offsetTop&&
        
         leftbomba+30>tiro.offsetLeft&&
         leftbomba-1<tiro.offsetLeft
         ){
          
          if(sim){
          tiro.remove()
            sim=false
          }
        let ploasao=document.querySelector('.audio')
        ploasao.currentTime=-2
         ploasao.play()
          bombas.src='explosão2.gif'
          
          setTimeout(()=>{
            bombas.remove()
            sim=true
           },800)
          
        
      
        }
    
  })
  }  
}


document.querySelector('.btnjogar').addEventListener('click',()=>{
  
document.querySelector('.painel').
 style.display='block'

document.querySelector('.telagmsg').style.display='none'
       ploasao.currentTime=100000000000
      ploasao.play()
  reset()
})








function fimdojogo(){



  if(vitoria){
    fim.style.display='block'
    fim.innerHTML='Vitória'
    fim.style.background='green'
    fim.style.border='4px solid black'
    
  }else{
        fim.style.display = 'block'
        fim.innerHTML = 'Derrota'
        fim.style.background = 'red'
           fim.style.border='4px solid black'
  }
  



  document.querySelectorAll('.atirajog').forEach((bombas, index) => {
         bombas.remove()
         })
         
         
           document.querySelectorAll('.bomba').forEach((bombas, index) => {
             bombas.remove()
           })
           
  document.querySelector('.painel').
   style.display = 'none'
  
  document.querySelector('.telagmsg').style.display = 'block'
}

